
Changed code to compile with chibios-20.3.x and added suggestion from [http://forum.chibios.org/viewtopic.php?t=5666](http://forum.chibios.org/viewtopic.php?t=5666)
I try some changes for compiling with chibios-21.11.x withouth success.
I will push it on the correct Chibios-Contrib branch
