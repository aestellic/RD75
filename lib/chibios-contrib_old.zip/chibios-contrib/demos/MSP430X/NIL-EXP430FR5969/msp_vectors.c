#include <msp430.h>

__attribute__((interrupt(1)))
void Vector1(void) {

  while (1) {
  }
}
__attribute__((interrupt(2)))
void Vector2(void) {

  while (1) {
  }
}
__attribute__((interrupt(3)))
void Vector3(void) {

  while (1) {
  }
}
__attribute__((interrupt(4)))
void Vector4(void) {

  while (1) {
  }
}
__attribute__((interrupt(5)))
void Vector5(void) {

  while (1) {
  }
}
__attribute__((interrupt(6)))
void Vector6(void) {

  while (1) {
  }
}
__attribute__((interrupt(7)))
void Vector7(void) {

  while (1) {
  }
}
__attribute__((interrupt(8)))
void Vector8(void) {

  while (1) {
  }
}
__attribute__((interrupt(9)))
void Vector9(void) {

  while (1) {
  }
}
__attribute__((interrupt(10)))
void Vector10(void) {

  while (1) {
  }
}
__attribute__((interrupt(11)))
void Vector11(void) {

  while (1) {
  }
}
__attribute__((interrupt(12)))
void Vector12(void) {

  while (1) {
  }
}
__attribute__((interrupt(13)))
void Vector13(void) {

  while (1) {
  }
}
__attribute__((interrupt(14)))
void Vector14(void) {

  while (1) {
  }
}
__attribute__((interrupt(15)))
void Vector15(void) {

  while (1) {
  }
}
__attribute__((interrupt(16)))
void Vector16(void) {

  while (1) {
  }
}
__attribute__((interrupt(17)))
void Vector17(void) {

  while (1) {
  }
}
__attribute__((interrupt(18)))
void Vector18(void) {

  while (1) {
  }
}
__attribute__((interrupt(19)))
void Vector19(void) {

  while (1) {
  }
}
__attribute__((interrupt(20)))
void Vector20(void) {

  while (1) {
  }
}
__attribute__((interrupt(21)))
void Vector21(void) {

  while (1) {
  }
}
__attribute__((interrupt(22)))
void Vector22(void) {

  while (1) {
  }
}
__attribute__((interrupt(23)))
void Vector23(void) {

  while (1) {
  }
}
__attribute__((interrupt(24)))
void Vector24(void) {

  while (1) {
  }
}
__attribute__((interrupt(25)))
void Vector25(void) {

  while (1) {
  }
}
__attribute__((interrupt(26)))
void Vector26(void) {

  while (1) {
  }
}
__attribute__((interrupt(27)))
void Vector27(void) {

  while (1) {
  }
}
__attribute__((interrupt(28)))
void Vector28(void) {

  while (1) {
  }
}
__attribute__((interrupt(29)))
void Vector29(void) {

  while (1) {
  }
}
__attribute__((interrupt(30)))
void Vector30(void) {

  while (1) {
  }
}
__attribute__((interrupt(31)))
void Vector31(void) {

  while (1) {
  }
}
__attribute__((interrupt(32)))
void Vector32(void) {

  while (1) {
  }
}
__attribute__((interrupt(33)))
void Vector33(void) {

  while (1) {
  }
}
__attribute__((interrupt(34)))
void Vector34(void) {

  while (1) {
  }
}
__attribute__((interrupt(35)))
void Vector35(void) {

  while (1) {
  }
}
__attribute__((interrupt(36)))
void Vector36(void) {

  while (1) {
  }
}
__attribute__((interrupt(37)))
void Vector37(void) {

  while (1) {
  }
}
__attribute__((interrupt(38)))
void Vector38(void) {

  while (1) {
  }
}
__attribute__((interrupt(39)))
void Vector39(void) {

  while (1) {
  }
}
__attribute__((interrupt(40)))
void Vector40(void) {

  while (1) {
  }
}
__attribute__((interrupt(41)))
void Vector41(void) {

  while (1) {
  }
}
__attribute__((interrupt(42)))
void Vector42(void) {

  while (1) {
  }
}
__attribute__((interrupt(43)))
void Vector43(void) {

  while (1) {
  }
}
__attribute__((interrupt(44)))
void Vector44(void) {

  while (1) {
  }
}
__attribute__((interrupt(45)))
void Vector45(void) {

  while (1) {
  }
}
__attribute__((interrupt(46)))
void Vector46(void) {

  while (1) {
  }
}
__attribute__((interrupt(47)))
void Vector47(void) {

  while (1) {
  }
}
__attribute__((interrupt(48)))
void Vector48(void) {

  while (1) {
  }
}
__attribute__((interrupt(50)))
void Vector50(void) {

  while (1) {
  }
}
__attribute__((interrupt(51)))
void Vector51(void) {

  while (1) {
  }
}
__attribute__((interrupt(53)))
void Vector53(void) {

  while (1) {
  }
}
__attribute__((interrupt(54)))
void Vector54(void) {

  while (1) {
  }
}
__attribute__((interrupt(55)))
void Vector55(void) {

  while (1) {
  }
}


