# WB32FQ95xx Serial MCU Demo

This is an example.

